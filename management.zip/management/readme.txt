
Welcome to the Restaurant Management System! This software is designed to help restaurant owners and managers to efficiently manage their restaurants' daily operations and improve customer satisfaction.

Features
Restaurant management: Add, edit, and remove Restaurants.
Table management: Assign and manage tables for customers.
Requirements
To run this software, you will need:

Operating System: Windows 7 or more, macOS, or Linux
PHP above 7
CodeIgniter web framework
MySQL database
Installation
Clone the repository or download the zip file.
Install PostgreSQL or MySQL database on your system.
Configure the database settings in the settings.py file.
Run the following command to migrate the database:
python manage.py migrate
Run the following command to start the server:
python manage.py runserver
Open a web browser and go to http://localhost/management to access the software.
Usage
To use the Restaurant Management System, follow these steps:

Login to the Web app with your username and password.
Navigate to the desired feature from the navigation menu.




