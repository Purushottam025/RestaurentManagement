$(document).ready(function () {
	$("#registerForm").validate({
		rules: {
      'date[]':{
        required: true,
      },
      firstName: {
				required: true,
				maxlength: 30,
			},
			lastName: {
				required: true,
				maxlength: 30,
			},
			email: {
				required: true,
				email: true,
			},
			mobileNumber: {
				required: true,
				maxlength: 10,
			},
			address: {
				required: true,
			},
			city: {
				required: true,
				maxlength: 30,
			},
			pinCode: {
				required: true,
				maxlength: 6,
				minlength: 6,
			},
			state: {
				required: true,
			},
			country: {
				required: true,
			},
			hobbies: {
				required: true,
			},
			classXBoard: {
				required: true,
				maxlength: 10,
			},
			classXPercentage: {
				required: true,
			},
			classXYear: {
				required: true,
			},
			classXIIBoard: {
				required: true,
				maxlength: 10,
			},
			classXIIPercentage: {
				required: true,
			},
			classXIIYear: {
				required: true,
			},
			graduationBoard: {
				required: true,
				maxlength: 10,
			},
			graduationPercentage: {
				required: true,
			},
			graduationYear: {
				required: true,
			},
			mastersBoard: {
				required: true,
				maxlength: 10,
			},
			mastersPercentage: {
				required: true,
			},
			mastersYear: {
				required: true,
			},
			gender: {
				required: true,
			},
			course: {
				required: true,
			},
			hobbies: {
				required: true,
			},
			birthday: {
				required: true,
			},
		},
		messages: {
			firstName: {
				required: "This Field is required",
				maxlength: jQuery.validator.format("max 30 characters required!"),
			},
			lastName: {
				required: "This Field is required",
				maxlength: jQuery.validator.format("max 30 characters required!"),
			},
			email: {
				required: "This Field is required",
				email: "Enter Valid Email",
			},
			mobileNumber: {
				required: "This Field is required",
				maxlength: jQuery.validator.format("Enter Valid Number"),
			},
			address: {
				required: "This Field is required",
			},
			city: {
				required: "This Field is required",
				maxlength: jQuery.validator.format("max 30 characters required!"),
			},
			pinCode: {
				required: "This Field is required",
				maxlength: jQuery.validator.format("6 characters required!"),
				minlength: jQuery.validator.format("6 characters required!"),
			},
			state: {
				required: "This Field is required",
			},
			country: {
				required: "This Field is required",
			},
			classXBoard: {
				required: "This Field is required",
				maxlength: jQuery.validator.format("max 10 characters required!"),
			},
			classXPercentage: {
				required: "This Field is required",
			},
			classXYear: {
				required: "This Field is required",
			},
			classXIIBoard: {
				required: "This Field is required",
				maxlength: jQuery.validator.format("max 10 characters required!"),
			},
			classXIIPercentage: {
				required: "This Field is required",
			},
			classXIIYear: {
				required: "This Field is required",
			},
			graduationBoard: {
				required: "This Field is required",
				maxlength: jQuery.validator.format("max 10 characters required!"),
			},
			graduationPercentage: {
				required: "This Field is required",
			},
			graduationYear: {
				required: "This Field is required",
			},
			mastersBoard: {
				required: "This Field is required",
				maxlength: jQuery.validator.format("max 10 characters required!"),
			},
			mastersPercentage: {
				required: "This Field is required",
			},
			mastersYear: {
				required: "This Field is required",
			},
			gender: {
				required: "This Field is required",
			},
			course: {
				required: "This Field is required",
			},
			hobbies: {
				required: "This Field is required",
			},
			birthday: {
				required: "This Field is required",
			},
		},
		/* submitHandler: function () {
			
		}, */
	});
	/* $("#firstName").keypress(function (e) {
		var keyCode = e.keyCode || e.which;

		$("#lblError").html("");

		//Regex for Valid Characters i.e. Alphabets.
		var regex = /^[A-Za-z]+$/;

		//Validate TextBox value against the Regex.
		var isValid = regex.test(String.fromCharCode(keyCode));
		if (!isValid) {
			$("#lblError").html("Only Alphabets allowed.");
		}
		return isValid;
	});
	$("#lastName").keypress(function (e) {
		var keyCode = e.keyCode || e.which;

		$("#lblError").html("");

		//Regex for Valid Characters i.e. Alphabets.
		var regex = /^[A-Za-z]+$/;

		//Validate TextBox value against the Regex.
		var isValid = regex.test(String.fromCharCode(keyCode));
		if (!isValid) {
			$("#lblError").html("Only Alphabets allowed.");
		}
		return isValid;
	}); */
});
