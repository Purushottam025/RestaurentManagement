<!-- Access denied page -->
<div class="py-5">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-8">
        <div class="card">
          <div class="card-header">
            <h4>403 Access Denied</h4>
          </div>
          <div class="card-body">
            <?php if ($this->session->flashdata('status')) : ?>
              <div class="alert alert-error">
                <?php echo $this->session->flashdata('status'); ?>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>