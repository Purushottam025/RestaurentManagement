<div class="py-5">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-5">
        <div class="card shadow">
          <div class="card-header">
            <h5>Welcome to Restaurent Management</h5>
          </div>
          <div class="card-body">
            <div class="container">
              <h2>Restaurents</h2>
              <p>Fine Dining. Fine dining restaurants offer diners an upscale meal experience often comprising several courses (e.g., salad, appetizer, entree, dessert). ... 
              <br/>Casual Dining. ...
              <br/>Fast Casual. ...
              <br/>Ghost Restaurant. ...
              <br/>Family Style Types Of Restaurants. ...
              <br/>Fast Food. ...
              <br/>Food Truck, Cart, Or Stand. ...
              <br/>Cafe.</p>
            </div>
        </div>
      </div>
    </div>
  </div>
</div>