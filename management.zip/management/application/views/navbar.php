<header class="header">
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="<?php echo base_url('Home_controller') ?>">Restaurent Management</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent" style="float: right;">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url('Home_controller') ?>">Home</a>
        </li>
        <?php if ($this->session->has_userdata('authenticated')) {  ?>
          <?php if ($this->session->userdata('auth_user')['role'] != 2) { ?>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="<?php echo base_url('User_controller') ?>" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">View Detals</a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                
                <a class="dropdown-item" href="<?php echo base_url('Restaurent_controller') ?>">Restaurents</a>
              </div>
            </li>
        <?php }
        } ?>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url('Admin_controller') ?>">Admin-Page</a>
        </li>
        <?php if ($this->session->has_userdata('authenticated')) {  ?>
          <?php if ($this->session->userdata('auth_user')['role'] == 2) { ?>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo base_url('Restaurent_controller') ?>">Restaurents</a>
            </li>
        <?php }
        } ?>
        <?php if (!$this->session->has_userdata('authenticated')) {  ?>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url('Register_controller') ?>">Register</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url('Login_controller') ?>">Login</a>
          </li>
        <?php } ?>
        <?php if ($this->session->has_userdata('authenticated')) {  ?>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
              <?php if ($this->session->has_userdata('authenticated')) {
                echo $this->session->userdata('auth_user')['email'];
              } else { ?>
                Email
              <?php } ?>
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="<?php echo base_url('Logout_controller') ?>">LogOut</a>
            </div>
          </li>
        <?php } ?>
      </ul>
    </div>
  </nav>
</header>