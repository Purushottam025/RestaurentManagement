<div class="py-5">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-7">
        <div class="card shadow">
          <div class="card-header">
            Register
          </div>
          <div class="card-body">
            <form method="POST" action="<?php echo base_url('Register_controller/register') ?>">
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Email Address</label>
                    <input type="email" name="email" value="<?php echo set_value('email'); ?>" id="email" class="form-control">
                    <small><?php echo form_error('email'); ?></small>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" id="password" class="form-control">
                    <small><?php echo form_error('password'); ?></small>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Confirm Password</label>
                    <input type="password" name="passwordConf" id="passwordConf" class="form-control">
                    <small><?php echo form_error('passwordConf'); ?></small>
                  </div>
                </div>
                <div class="col-md-12">
                  <button type="submit" class="btn btn-primary px-5">Regsiter!</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>