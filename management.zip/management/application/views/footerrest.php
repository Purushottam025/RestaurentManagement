<script src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.7.2.min.js"></script>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>
<script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<!--Below scripts are working-->
<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<script src="http://code.jquery.com/ui/1.11.0/jquery-ui.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script>
  $(document).on("click", "#add", function(e) {
    e.preventDefault();
    var data = $('#form').serialize();
    $.ajax({
      url: "<?php echo base_url('Restaurent_controller/addRestaurent'); ?>",
      type: "POST",
      dataType: "json",
      data: data,
      success: function(data) {
        $('#exampleModalCenter').modal('hide');
        if (data.response == "success") {
          toastr["success"](data.message)
          getrest();
          toastr.options = {
            "closeButton": true,
            "debug": false,
            "newestOnTop": false,
            "progressBar": true,
            "positionClass": "toast-top-right",
            "preventDuplicates": false,
            "onclick": null,
            "showDuration": "300",
            "hideDuration": "1000",
            "timeOut": "5000",
            "extendedTimeOut": "1000",
            "showEasing": "swing",
            "hideEasing": "linear",
            "showMethod": "fadeIn",
            "hideMethod": "fadeOut"
          }
          getrest();
        } else {
          toastr["error"](data.message)
          toastr.options = {
            "closeButton": true,
            "debug": false,
            "newestOnTop": false,
            "progressBar": true,
            "positionClass": "toast-top-right",
            "preventDuplicates": false,
            "onclick": null,
            "showDuration": "300",
            "hideDuration": "1000",
            "timeOut": "5000",
            "extendedTimeOut": "1000",
            "showEasing": "swing",
            "hideEasing": "linear",
            "showMethod": "fadeIn",
            "hideMethod": "fadeOut"
          }
        }
      }
    });
    $('#form')[0].reset();
    getrest();
  });

  function getrest() { 
    $.ajax({
      url: "<?php echo base_url('Restaurent_controller/getrests'); ?>",
      type: "post",
      dataType: "json",
      success: function(data) {
        var tbody = "";
        var i;
        var number = 0;
        console.log(data);
        for (i = 0; i < data.length; i++) {
          tbody += "<tr>";
          tbody += "<td>" + ++number + "</td>";
          tbody += "<td><img src='" + data[i].image + "' style='width:50px; height:50px;'></td>";
          tbody += "<td>" + data[i].restaurent_Name + "</td>";
          tbody += "<td>" + data[i].Address + "</td>";
          <?php if ($this->session->userdata('auth_user')['role'] != 1) { ?>
            tbody += '<td> <a class="btn btn-outline-info btn-sm mr-1" href="#" id="edit" value=' + data[i].Id + '>Edit</a><a class="btn btn-outline-danger btn-sm" href="#" id="del" value=' + data[i].Id + '>Delete</a> <a class="btn btn-outline-dark btn-sm mr-1" href="#" id="upload" value=' + data[i].Id + '>Upload Image</a></td>';
          <?php } else{?>
            tbody += '<td> <a class="btn btn-outline-info btn-sm mr-1" href="#" id="view" value=' + data[i].Id + '>View Details</a></td>';
            <?php }?>
          tbody += "</tr>";
        }
        $('#tbody').html(tbody);
      }
    });
  }
  getrest();

  $(document).on("click", "#del", function(e) {
    e.preventDefault();
    var del_id = $(this).attr("value");
    $.confirm({
      title: 'Delete Details!',
      content: 'Are you sure you want to delete the details?',
      theme: 'supervan',
      buttons: {
        confirm: function() {
          $.ajax({
            url: "<?php echo base_url('Restaurent_controller/deleteRestaurent'); ?>",
            type: "post",
            dataType: "json",
            data: {
              del_id: del_id
            },
            success: function(data) {
              if (data.response == "success") {
                getrest();
              }
            }
          })
        },
        cancel: function() {},
      }
    });
  });
  getrest();
  $(document).on("click", "#edit", function(e) {
    e.preventDefault();
    var edit_id = $(this).attr("value");
    $.ajax({
      url: "<?php echo base_url('Restaurent_controller/editRestaurent') ?>",
      type: "POST",
      dataType: "json",
      data: {
        edit_id: edit_id,
      },
      success: function(data) {
        if (data.response == "success") {
          $('#editModal').modal('show');
          $('#editRestId').val(data.post.Id);
          $('#restaurent_Name').val(data.post.restaurent_name);
          $('#Address').val(data.post.address);
        } else {
          toastr["error"](data.message)
        }
      }
    });
  });

  $(document).on("click", "#update", function(e) {
    e.preventDefault();
    var editRestId = $('#editRestId').val();
    var editCategory = $('#restaurent_Name').val();
    var editRest = $('#Address').val();
    var data = $('#editForm').serialize();

    if (editRest == "" || editCategory == "") {
      alert("All fields are required");
    } else {
      $.ajax({
        url: "<?php echo base_url('Restaurent_controller/updateRestaurent') ?>",
        type: "POST",
        dataType: "json",
        data: data,
        success: function(data) {
          if (data.response == "success") {
            $('#editModal').modal('hide');
            getrest();
            toastr["success"](data.message)
          } else {
            toastr["error"](data.message)
          }
        }
      })
    }
  });
  $(document).on("click", "#upload", function(e) {
    e.preventDefault();
    var id = $(this).attr("value");
    $('#uploadModal').modal('show');
    $('#upload_form').on('submit', function(e) {
      e.preventDefault();
      if ($('#image_file').val() == '') {
        alert("Please Select the File");
      } else {
        $.ajax({
          url: '<?php echo base_url('ImageUpload_controller/ajaxImageStore/') ?>'+id,
          method: "POST",
          data: new FormData(this),
          contentType: false,
          cache: false,
          processData: false,
          dataType: "json",
          success: function(res) {
            console.log(res.success);
            if (res.success == true) {
              $('#msg').html(res.msg);
              $('#divMsg').show();
              toastr["success"]('Image uploaded successfully!')
              getrest();
              toastr.options = {
                "closeButton": true,
                "debug": false,
                "newestOnTop": false,
                "progressBar": true,
                "positionClass": "toast-top-right",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
              }
              $('#uploadModal').modal('hide');
            } else if (res.success == false) {
              $('#msg').html(res.msg);
              $('#divMsg').show();
            }
            setTimeout(function() {
              $('#msg').html('');
              $('#divMsg').hide();
            }, 3000);
          }
        });
      }
    });
  });
  $(document).on("click","#view",function(e){
    e.preventDefault();
    $('#viewImageModal').modal('show');
    var id = $(this).attr("value");
    $.ajax({
      url: "<?php echo base_url('Restaurent_controller/getRestaurentImage/') ?>"+id,
      type: "POST",
      dataType: "json",
      data: {
        id: id,
      },
      success: function(data) {
        if (data.response == "success") {
          console.log(data.post)
          if(data.post.restaurent_image){
            $('#image').attr('src','<?php echo base_url('assets/uploads')?>'+'/'+(data.post.restaurent_image));
          }else{
            $('#image').attr('src','<?php echo base_url('assets/uploads/2020-three-quarters-3.png')?>');
          }
          document.getElementById('viewRest').innerHTML = data.post.restaurent_name;
          document.getElementById('viewAddress').innerHTML = 'Location: '+data.post.address;
        } else {
          toastr["error"](data.message);
          $('#image').attr('src','');
        }
      }
    });
  });
 
</script>
<script type="text/javascript" src="<?php echo base_url() ?>assets/js/custom.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
<script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>
</body>

</html>