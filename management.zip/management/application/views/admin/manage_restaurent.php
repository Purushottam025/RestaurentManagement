<div class="container">
  <div class="row">
    <div class="col-md-12 mt-5">
      <h1 class="text-center">Restaurent List</h1>
      <hr style="background-color: black; color: black; height: 1px;">
    </div>
  </div>
  <div class="row">
    <div class="col-md-12 mt-2">
      <?php if ($this->session->userdata('auth_user')['role'] != 1) { ?>
        <button type="button" class="btn btn-outline-success btn-sm" data-toggle="modal" data-target="#exampleModalCenter">
          Add Restaurent
        </button>
      <?php } ?>
      <!-- Modal -->
      <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLongTitle">Add Restaurent</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <form method="POST" action="" id="form">
                <div class="form-group">
                  <label>Restaurent Name</label>
                  <input type="text" id="restaurent_name" name="restaurent_name" class="form-control">
                  <p><small><?php echo form_error('restaurent_name'); ?></small></p>
                </div>
                <div class="form-group">
                  <label>Address</label>
                  <textarea class="form-control" id="address" name="address" rows="4" cols="50"> </textarea>
                  <p><small><?php echo form_error('address'); ?></small></p>
                </div>
              </form>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="button" class="btn btn-primary" id="add">Add Restaurent</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-12 mt-3">
      <div class="table-responsive">
        <table class="table" id="records">
          <thead>
            <tr>
              <th>Sr. No</th>
              <th>Image</th> 
              <th>Restaurent Name</th>
              <th>Address</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody id="tbody">

          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Restaurent</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="POST" action="" id="editForm">
        <input type="hidden" id="editRestId" name="editRestId" class="form-control">
          <div class="form-group">
            <label>Restaurent Name</label>
            <input type="text" id="restaurent_Name" name="restaurent_Name" class="form-control">
            <p><small><?php echo form_error('restaurent_Name'); ?></small></p>
          </div>
          <div class="form-group">
            <label>Address</label>
            <textarea class="form-control" id="Address" name="Address" rows="4" cols="50"> </textarea>
            <p><small><?php echo form_error('Address'); ?></small></p>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="update">Update</button>
      </div>
    </div>
  </div>
</div>

<!-- Image Upload Modal -->
<div class="modal fade" id="uploadModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Upload Restaurent Image</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" id="upload_form" enctype="multipart/form-data">
          <div class="col-md-7">
            <div id="divMsg" class="alert alert-success" style="display: none">
              <span id="msg"></span>
            </div>
            <input type="file" name="image_file" multiple="true" accept="image/*" id="finput"></br></br>
            <button class="btn btn-outline-success">Submit</button>
          </div>
          <div class="col-md-5"></div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- View Image Modal -->
<div class="modal fade" id="viewImageModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Restaurent Image</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <!-- <form method="post" id="upload_form" enctype="multipart/form-data"> -->
          <div class="col-md-12">
            <h2 class="text-center" id="viewRest" name="viewRest"> </h2>
            <!-- <input type="text" value="" name="viewRest" id="viewRest" readonly disabled> -->
          </div>
          <div class="col-md-12">
            <p id="viewAddress" class="text-center"></p>
            <!-- <input type="text" value="" name="viewAddress" id="viewAddress"readonly disabled> -->
          </div>
          <div class="col-md-12 text-center">
            <img id="image" src="" alt="image" class="rounded mx-auto d-block" style="max-width: 250px; max-height: 250px;"/></br></br>
          </div>
        <!-- </form> -->
      </div>
    </div>
  </div>
</div>