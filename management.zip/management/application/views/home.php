<div class="py-5">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-12">
        <div class="card shadow">
          <img src="<?php echo base_url('assets/images/restaurent.jpg')?>" style= "height:auto; width:1120px;">
        </div>
      </div>
    </div>
  </div>
</div>