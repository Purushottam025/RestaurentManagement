<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Restaurent_controller extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Register_model');
		$this->load->model('Restaurent_model');
		$this->load->model('Authentication_model');
	}

	public function index()
	{
		$this->load->view('header');
		$this->load->view('admin/manage_restaurent');
		$this->load->view('footerrest');
	}

	public function addRestaurent()
	{
		if ($this->input->is_ajax_request()) {
			$this->form_validation->set_rules('restaurent_name', 'restaurent_name', 'trim|required|is_unique[restaurents.restaurent_name]');
			$this->form_validation->set_rules('address', 'address', 'required');
			if ($this->form_validation->run() == FALSE) {
				$data = array('response' => 'error', 'message' => validation_errors());
			} else {
				$ajax_data = $this->input->post();

				if ($this->Restaurent_model->addRest($ajax_data)) {
					$data = array('response' => 'success', 'message' => 'Data Added Successfully');
				} else {
					$data = array('response' => 'error', 'message' => 'Operation Failed');
				}
			}
		} else {
			echo "No direct scripts allowed";
		}
		echo json_encode($data);
	}

	public function getrests()
	{
		if ($this->input->is_ajax_request()) {
			$data = $this->Restaurent_model->getAllData();
			echo json_encode($data);
		} else {
			echo "No direct script allowed";
		}
	}

	public function deleteRestaurent()
	{
		if ($this->input->is_ajax_request()) {
			$del_id = $this->input->post('del_id');
			if ($this->Restaurent_model->deleteRestaurent($del_id)) {
				$data = array('response' => 'success', 'message' => 'Data Deleted Successfully');
			} else {
				$data = array('response' => 'error', 'message' => 'Operation Failed');
			}
			echo json_encode($data);
		} else {
			echo "No direct scripts allowed";
		}
	}

	public function editRestaurent()
	{
		if ($this->input->is_ajax_request()) {
			$edit_id = $this->input->post('edit_id');
			if ($post = $this->Restaurent_model->editRestaurent($edit_id)) {
				$data = array("response" => "success", "post" => $post);
			} else {
				$data = array("response" => "error", "message" => "failed to fetch record");
			}
			echo json_encode($data);
		} else {
			echo "No direct scripts access allowed";
		}
	}

	public function updateRestaurent()
	{
		
		if ($this->input->is_ajax_request()) {
			$this->form_validation->set_rules('restaurent_Name', 'restaurent_Name', 'trim|required');
			$this->form_validation->set_rules('Address', 'Address', 'required');
			if ($this->form_validation->run() == FALSE) {
				$data = array('response' => 'error', 'message' => validation_errors());
			} else {
				$data = $this->input->post();
				
				if ($this->Restaurent_model->updateRestaurent($data)) {
					$data = array('response' => 'success', 'message' => 'Data Updated Successfully');
				} else {
					$data = array('response' => 'error', 'message' => 'Operation Failed');
				}
			}
			echo json_encode($data);
		} else {
			echo "No direct scripts allowed";
		}
	}

	public function getRestaurentImage(){
		if ($this->input->is_ajax_request()) {
			$id = $this->input->post('id');
			if ($post = $this->Restaurent_model->getRestaurentImage($id)) {
				$data = array("response" => "success", "post" => $post);
			} else {
				$data = array("response" => "error", "message" => "image not availabe");
			}
			echo json_encode($data);
		} else {
			echo "No direct scripts access allowed";
		}
	}
}
