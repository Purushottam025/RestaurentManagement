<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin_controller extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Register_model');
		$this->load->model('Restaurent_model');
		$this->load->model('Authentication_model');
		//To check that loggedin user is admin or not to provida access to other pages
		$this->Authentication_model->isAdmin();
	}

	public function index()
	{
		$this->load->view('header');
		$this->load->view('adminpage');
		$this->load->view('footer');
	}
}
