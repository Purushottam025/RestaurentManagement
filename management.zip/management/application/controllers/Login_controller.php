<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Login_controller extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    if ($this->session->has_userdata('authenticated')) {
      $this->session->set_flashdata('status', 'You are already loggedin');
      redirect(base_url('User_controller'));
    }
    $this->load->model('Register_model');
  }

  public function index()
  {
    $this->load->view('header');
    $this->load->view('login');
    $this->load->view('footer');
  }

  //Login function to server silde validate fields and to give access to user afterwords
  public function login()
  {
    $this->form_validation->set_rules('email', 'Email Address', 'trim|required|valid_email');
    $this->form_validation->set_rules('password', 'Password', 'trim|required|md5');
    if ($this->form_validation->run() == FALSE) {
      $this->index();
    } else {
      $data = array(
        'email' => $this->input->post('email'),
        'password' => $this->input->post('password')
      );
      $result = $this->Register_model->loginUser($data);
      if ($result != FALSE) {
        $auth_userdetails = [
          'id' => $result->id,
          'email' => $result->email,
          'role' => $result->role,
        ];
        //set session for current loggedin user
        $this->session->set_userdata('authenticated', $result->role);
        $this->session->set_userdata('auth_user', $auth_userdetails);
        $this->session->set_flashdata('status', 'Login Successfull');
        if ($result->role == 1) {
          redirect(base_url('User_controller'));
        } else {
          redirect(base_url('Admin_controller'));
        }
      } else {
        $this->session->set_flashdata('status', 'Invalid Credentials');
        redirect(base_url('Login_controller'));
      }
    }
  }
}
