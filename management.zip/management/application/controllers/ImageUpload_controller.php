<?php
class ImageUpload_controller extends CI_Controller {
  
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Restaurent_model');
    }
 
    public function image()
    {
      $this->load->view('image');
    }
 
    function ajaxImageStore($id)  
    {  
         if(isset($_FILES["image_file"]["name"]))  
         {     
              $config['upload_path'] = './assets/uploads/';  
              $config['allowed_types'] = 'jpg|jpeg|png|gif';
              $this->load->library('upload', $config);  
              if(!$this->upload->do_upload('image_file'))  
              {  
                  $error =  $this->upload->display_errors(); 
                  echo json_encode(array('msg' => $error, 'success' => false));
              }  
              else 
              {  
                   $data = $this->upload->data();
                   $update['restaurent_image'] = $data['file_name'];
                   $update['Id'] = $id;
                    // load the model first
                   if($this->Restaurent_model->updateImage($update)) // call the method from the model
                   {
                     $arr = array('msg' => 'Image has been uploaded successfully', 'success' => true);
                   }
                   else
                   {
                     $arr = array('msg' => 'Image has not uploaded successfully', 'success' => false);
                   }
                   echo json_encode($arr);
              }  
         }  
    } 
     
}