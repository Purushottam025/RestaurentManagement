<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register_controller extends CI_Controller{
  public function __construct()
  {
    parent:: __construct();
    if($this->session->has_userdata('authenticated')){
      $this->session->set_flashdata('status','You are already loggedin');
      redirect(base_url('User_controller'));
    }
    $this->load->model('Register_model');
  }

  public function index(){
    $this->load->view('header');
    $this->load->view('register');
    $this->load->view('footer');
  }

  //Function to register user and also validate register form data
  public function register(){
    $this->form_validation->set_rules('email','Email Address','trim|required|valid_email|is_unique[roles.email]');
    $this->form_validation->set_rules('password','Password','trim|required|md5');
    $this->form_validation->set_rules('passwordConf','Confirm Password','trim|required|matches[password]|md5');
    if($this->form_validation->run() == FALSE){
      //failed
      $this->index();
    }else{
      $data = array(
        'email' => $this->input->post('email'),
        'password' => $this->input->post('password')
      );
        $check = $this->Register_model->registerUser($data);
        if($check){
          $this->session->set_flashdata('status','Registered Successfully !');
          redirect(base_url('Login_controller/login'));
        }else{
          $this->session->set_flashdata('status','Something went wrong!');
          redirect(base_url('Register_controller/register'));
        }
    }

  }
}

?>