<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User_controller extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->load->model('Authentication_model');
    $this->load->model('Register_model');
    $this->load->model('Restaurent_model');
  }

  //Function to load user page
  public function index()
  {
    $id = $this->session->userdata('auth_user')['id'];
    $this->load->view('header');
    $data['result']  = $this->Restaurent_model->getAllData();
    $data['flag'] = 0;
    $this->load->view('userpage', $data);
    $this->load->view('footer');
  }
}
