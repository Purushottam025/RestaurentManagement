<?php

class Authentication_model extends CI_Model{

  public function __construct()
  {
    parent:: __construct();
    if($this->session->has_userdata('authenticated')){
      if($this->session->userdata('authenticated') == 1){
        //Accessible
      }
    }else{
      $this->session->set_flashdata('status','Login First');
      redirect(base_url('Login_controller'));
    }
    
  }

  //Function to check if loggedin user is admin or not
  public function isAdmin(){
    if($this->session->has_userdata('authenticated')){
      if($this->session->userdata('authenticated') != 2){
        $this->session->set_flashdata('status','Access Denied.! You are not Admin');
        redirect(base_url('AccessDenied_controller'));
      }
    }else{
      $this->session->set_flashdata('status','Login First');
      redirect(base_url('Login_controller'));
    }
  }
}

?>