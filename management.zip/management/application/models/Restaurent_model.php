<?php

class Restaurent_model extends CI_Model
{


	public function addRest($data)
	{
		return $this->db->insert('restaurents', $data);
	}

	//Function to fetch restarent data from database
	public function getAllData()
	{
		$image = '';
		$dataArray = array();
		$this->db->select('*');
		$this->db->from('restaurents');
		//$this->db->inner('category');
		$query = $this->db->get();
		if ($query->result()) {
			$result = $query->result();
			foreach ($result as $row) {
				$data['Id'] = $row->Id;
				$data['restaurent_Name'] = $row->restaurent_name;
				$data['Address'] = $row->address;
				$path = base_url().'assets/uploads/';
				$data['image'] = $row->restaurent_image ? $path.$row->restaurent_image : $path.'2020-three-quarters-3.png' ;
				$dataArray[] = $data;
			}
			return $dataArray;
		}
	}

	public function deleteRestaurent($id){
		return $this->db->delete('restaurents',array('Id' => $id));
	}

	public function editRestaurent($id){
		$this->db->select('*');
		$this->db->from('restaurents');
		$this->db->where('Id',$id);
		$query = $this->db->get();
		if(count($query->result()) > 0){
			return $query->row();
		}
	}

	public function updateRestaurent($data){
		$dataArray = array(	
			'restaurent_name' => $data['restaurent_Name'],
			'address' => $data['Address'],
		);
	return $this->db->update('restaurents',$dataArray, array('Id' => $data['editRestId']));
	}

	public function updateImage($data){
		$dataArray = array(	
			'restaurent_image' => $data['restaurent_image'],
		);
	return $this->db->update('restaurents',$dataArray, array('Id' => $data['Id']));
	}

	public function getRestaurentImage($id){
		$this->db->select('*');
		$this->db->from('restaurents');
		$this->db->where('Id',$id);
		$query = $this->db->get();
		if(count($query->result()) > 0){
			return $query->row();
		}
	}
}
