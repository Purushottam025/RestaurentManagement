<?php

class Register_model extends CI_Model
{
	//Function to insert user data to database
	public function registerUser($data)
	{
		return $this->db->insert('roles', $data);
	}

	//Function to fetch user data from database to authenticate
	public function loginUser($data)
	{
		$this->db->select('*');
		$this->db->where('email', $data['email']);
		$this->db->where('password', $data['password']);
		$this->db->from('roles');
		$this->db->limit(1);
		$query = $this->db->get();
		if ($query->num_rows() == 1) {
			return $query->row();
		} else {
			return false;
		}
	}
}
